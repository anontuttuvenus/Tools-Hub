"""
APIHound — Burp Suite Extension (Montoya API)
Passive + Active scanning integration for Burp Suite 2023+.
Requires Jython 2.7+ standalone JAR.

Install: Extender → Add → Extension Type: Python → Select this file.
"""
from burp import IBurpExtender, IScannerCheck, ITab
from java.io import PrintWriter
from javax.swing import JPanel, JTextArea, JScrollPane, JButton, JLabel, BoxLayout
import json
import re


class BurpExtender(IBurpExtender, IScannerCheck, ITab):
    """APIHound Burp Suite extension for passive API security analysis."""

    EXTENSION_NAME = "APIHound v2.0"

    # Patterns indicating potential API vulnerabilities
    SENSITIVE_PATTERNS = [
        (r'"password"\s*:\s*"[^"]+"', "API3: Password in response", "HIGH"),
        (r'"api[_-]?key"\s*:\s*"[^"]+"', "API3: API key in response", "HIGH"),
        (r'"secret"\s*:\s*"[^"]+"', "API3: Secret in response", "HIGH"),
        (r'"token"\s*:\s*"[^"]+"', "API3: Token in response", "MEDIUM"),
        (r'"access_token"\s*:\s*"[^"]+"', "API3: Access token in response", "HIGH"),
        (r'"private_key"\s*:\s*"[^"]+"', "API3: Private key in response", "CRITICAL"),
        (r'"ssn"\s*:\s*"[^"]+"', "API3: SSN in response", "CRITICAL"),
        (r'(?:AKIA|ABIA|ACCA|ASIA)[0-9A-Z]{16}', "API3: AWS access key in response", "CRITICAL"),
        (r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----', "API3: Private key in response", "CRITICAL"),
    ]

    MISCONFIG_HEADERS = [
        ("X-Powered-By", "API8: Technology disclosure via X-Powered-By"),
        ("Server", "API8: Server version disclosure"),
    ]

    MISSING_HEADERS = [
        "Strict-Transport-Security",
        "X-Content-Type-Options",
        "X-Frame-Options",
        "Content-Security-Policy",
    ]

    def registerExtenderCallbacks(self, callbacks):
        """Burp calls this on extension load."""
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        self._stdout = PrintWriter(callbacks.getStdout(), True)
        self._stderr = PrintWriter(callbacks.getStderr(), True)

        callbacks.setExtensionName(self.EXTENSION_NAME)
        callbacks.registerScannerCheck(self)

        # Build UI tab
        self._panel = JPanel()
        self._panel.setLayout(BoxLayout(self._panel, BoxLayout.Y_AXIS))
        self._panel.add(JLabel("APIHound v2.0 — OWASP API Security Scanner"))
        self._panel.add(JLabel("Passive checks run automatically on proxied API traffic."))

        self._log_area = JTextArea(20, 80)
        self._log_area.setEditable(False)
        self._panel.add(JScrollPane(self._log_area))

        callbacks.addSuiteTab(self)

        self._stdout.println("[+] APIHound v2.0 loaded successfully")
        self._stdout.println("[+] Passive scanning active on all API traffic")
        self._log("[+] APIHound initialized. Passive checks active.")

    # -- ITab --
    def getTabCaption(self):
        return "APIHound"

    def getUiComponent(self):
        return self._panel

    # -- IScannerCheck --
    def doPassiveScan(self, baseRequestResponse):
        """Passive analysis on every proxied request/response."""
        issues = []

        response = baseRequestResponse.getResponse()
        if not response:
            return None

        analyzedResp = self._helpers.analyzeResponse(response)
        body = self._helpers.bytesToString(response[analyzedResp.getBodyOffset():])
        headers = analyzedResp.getHeaders()

        # Check 1: Sensitive data in response body
        for pattern, title, severity in self.SENSITIVE_PATTERNS:
            if re.search(pattern, body, re.IGNORECASE):
                issues.append(self._create_issue(
                    baseRequestResponse, title,
                    "Response body contains sensitive data that should not be exposed.",
                    severity,
                ))
                self._log(f"[!] {title} found in response")

        # Check 2: Missing security headers
        header_names = {h.split(":")[0].strip().lower() for h in headers if ":" in h}
        missing = [h for h in self.MISSING_HEADERS if h.lower() not in header_names]
        if missing:
            issues.append(self._create_issue(
                baseRequestResponse,
                f"API8: Missing security headers ({len(missing)})",
                f"Missing: {', '.join(missing)}",
                "LOW",
            ))

        # Check 3: CORS misconfiguration
        for h in headers:
            if h.lower().startswith("access-control-allow-origin:"):
                origin = h.split(":", 1)[1].strip()
                if origin == "*":
                    issues.append(self._create_issue(
                        baseRequestResponse,
                        "API8: CORS wildcard origin",
                        "Access-Control-Allow-Origin is set to '*'.",
                        "MEDIUM",
                    ))

        # Check 4: Verbose error detection
        analyzedResp_code = analyzedResp.getStatusCode()
        if analyzedResp_code >= 400:
            error_sigs = ["traceback", "stack trace", "exception", "sql", "debug"]
            body_lower = body.lower()
            if any(sig in body_lower for sig in error_sigs):
                issues.append(self._create_issue(
                    baseRequestResponse,
                    "API8: Verbose error message",
                    "Error response contains stack traces or internal details.",
                    "MEDIUM",
                ))

        # Check 5: JWT issues (passive)
        request = baseRequestResponse.getRequest()
        analyzedReq = self._helpers.analyzeRequest(request)
        for header in analyzedReq.getHeaders():
            if header.lower().startswith("authorization: bearer "):
                token = header.split(" ", 2)[-1].strip()
                if token.count(".") == 2:
                    self._analyze_jwt_passive(token, baseRequestResponse, issues)

        return issues if issues else None

    def doActiveScan(self, baseRequestResponse, insertionPoint):
        """Active scanning — returns None (use standalone tool for active tests)."""
        return None

    def consolidateDuplicateIssues(self, existingIssue, newIssue):
        """Deduplicate findings."""
        if existingIssue.getIssueName() == newIssue.getIssueName():
            return -1  # Keep existing
        return 0  # Keep both

    # -- Helpers --

    def _analyze_jwt_passive(self, token, baseRequestResponse, issues):
        """Passively analyze JWT for weak configurations."""
        import base64
        parts = token.split(".")
        try:
            header_b64 = parts[0] + "=" * (4 - len(parts[0]) % 4)
            header = json.loads(base64.urlsafe_b64decode(str(header_b64)))

            alg = header.get("alg", "")
            if alg.lower() == "none":
                issues.append(self._create_issue(
                    baseRequestResponse,
                    "API2: JWT uses 'none' algorithm",
                    "JWT token uses alg:none which means no signature verification.",
                    "CRITICAL",
                ))

            payload_b64 = parts[1] + "=" * (4 - len(parts[1]) % 4)
            payload = json.loads(base64.urlsafe_b64decode(str(payload_b64)))

            if "exp" not in payload:
                issues.append(self._create_issue(
                    baseRequestResponse,
                    "API2: JWT has no expiration",
                    "JWT token does not have an 'exp' claim.",
                    "MEDIUM",
                ))

        except Exception:
            pass  # Not a valid JWT — skip

    def _create_issue(self, baseRequestResponse, name, detail, severity):
        """Create a Burp IScanIssue."""
        return CustomScanIssue(
            self._helpers.analyzeRequest(baseRequestResponse).getUrl(),
            name,
            detail,
            severity,
            baseRequestResponse,
            self._callbacks,
        )

    def _log(self, message):
        """Append to UI log."""
        self._log_area.append(message + "\n")


class CustomScanIssue:
    """Implements Burp's IScanIssue interface."""

    def __init__(self, url, name, detail, severity, baseRequestResponse, callbacks):
        self._url = url
        self._name = name
        self._detail = detail
        self._severity = severity
        self._baseRequestResponse = baseRequestResponse
        self._service = baseRequestResponse.getHttpService()

    def getUrl(self):
        return self._url

    def getIssueName(self):
        return self._name

    def getIssueType(self):
        return 0

    def getSeverity(self):
        severity_map = {"CRITICAL": "High", "HIGH": "High", "MEDIUM": "Medium", "LOW": "Low", "INFO": "Information"}
        return severity_map.get(self._severity, "Information")

    def getConfidence(self):
        return "Certain"

    def getIssueBackground(self):
        return "Detected by APIHound v2.0 — OWASP API Security Top 10 Scanner."

    def getRemediationBackground(self):
        return None

    def getIssueDetail(self):
        return self._detail

    def getRemediationDetail(self):
        return None

    def getHttpMessages(self):
        return [self._baseRequestResponse]

    def getHttpService(self):
        return self._service
