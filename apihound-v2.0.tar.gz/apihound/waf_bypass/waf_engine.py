"""
APIHound — WAF Bypass Engine
Encoding, obfuscation, case variation, verb tampering, null bytes, header tricks.
Sources: Common WAF bypass techniques from research and bug bounty experience.
"""
import base64
import json
import logging
import random
import urllib.parse
from typing import Optional, Tuple

logger = logging.getLogger("apihound.waf")


class WAFBypassEngine:
    """Transform requests to evade Web Application Firewalls."""

    # Technique registry — each technique is a callable transformation
    TECHNIQUES = [
        "url_encode",
        "double_url_encode",
        "unicode_encode",
        "case_variation",
        "null_byte_inject",
        "comment_injection",
        "whitespace_variation",
        "verb_tampering",
        "header_injection",
        "chunked_encoding",
        "content_type_switch",
        "parameter_pollution",
        "json_unicode_escape",
        "path_normalization",
    ]

    def __init__(self, techniques: Optional[list] = None):
        self.active_techniques = techniques or self.TECHNIQUES
        self._technique_index = 0

    def transform_request(
        self,
        method: str,
        url: str,
        headers: dict,
        params: Optional[dict],
        body: Optional[dict],
    ) -> Tuple[str, str, dict, Optional[dict], Optional[dict]]:
        """
        Apply WAF bypass transformations to a request.
        Rotates through techniques on each call.
        """
        technique = self.active_techniques[self._technique_index % len(self.active_techniques)]
        self._technique_index += 1

        logger.debug(f"WAF bypass technique: {technique}")

        if technique == "verb_tampering":
            method, headers = self._verb_tamper(method, headers)
        elif technique == "header_injection":
            headers = self._inject_bypass_headers(headers)
        elif technique == "content_type_switch":
            headers, body = self._switch_content_type(headers, body)
        elif technique == "url_encode":
            url = self._url_encode_path(url)
        elif technique == "double_url_encode":
            url = self._double_url_encode_path(url)
        elif technique == "unicode_encode":
            url = self._unicode_encode_path(url)
        elif technique == "null_byte_inject":
            url = self._null_byte_path(url)
        elif technique == "path_normalization":
            url = self._path_normalization(url)
        elif technique == "parameter_pollution":
            params = self._parameter_pollution(params)
        elif technique == "json_unicode_escape":
            body = self._json_unicode_escape(body)
        elif technique == "case_variation":
            url = self._case_variation(url)
        elif technique == "whitespace_variation":
            body = self._whitespace_variation(body)
        elif technique == "comment_injection":
            body = self._comment_injection(body)
        elif technique == "chunked_encoding":
            headers = self._chunked_encoding(headers)

        return method, url, headers, params, body

    def transform_payload(self, payload: str, technique: str = "auto") -> list:
        """
        Generate multiple encoded variants of a payload.
        Returns list of transformed payloads.
        """
        variants = [payload]  # Always include original

        # URL encoding
        variants.append(urllib.parse.quote(payload))
        # Double URL encoding
        variants.append(urllib.parse.quote(urllib.parse.quote(payload)))
        # Unicode escapes
        variants.append(self._to_unicode_escapes(payload))
        # Mixed case
        variants.append(self._random_case(payload))
        # HTML entity encoding
        variants.append(self._html_entity_encode(payload))
        # Null byte insertion
        variants.append(payload + "%00")
        # Tab/newline injection
        variants.append(payload.replace(" ", "%09"))
        variants.append(payload.replace(" ", "%0a"))
        # Comment insertion (for SQL)
        variants.append(payload.replace(" ", "/**/"))
        # Base64
        variants.append(base64.b64encode(payload.encode()).decode())

        return list(set(variants))  # Deduplicate

    # -------------------------------------------------------------------------
    # Individual technique implementations
    # -------------------------------------------------------------------------

    def _verb_tamper(self, method: str, headers: dict) -> Tuple[str, dict]:
        """Use HTTP method override to bypass method-based WAF rules."""
        overrides = [
            ("X-HTTP-Method-Override", method),
            ("X-HTTP-Method", method),
            ("X-Method-Override", method),
        ]
        override_header, value = random.choice(overrides)
        new_headers = dict(headers)
        new_headers[override_header] = value

        # Send as GET or POST while overriding the real method
        tampered_method = random.choice(["GET", "POST"])
        logger.debug(f"Verb tamper: {method} -> {tampered_method} + {override_header}: {value}")
        return tampered_method, new_headers

    def _inject_bypass_headers(self, headers: dict) -> dict:
        """Add common WAF bypass headers."""
        bypass_headers = {
            "X-Originating-IP": "127.0.0.1",
            "X-Forwarded-For": "127.0.0.1",
            "X-Remote-IP": "127.0.0.1",
            "X-Client-IP": "127.0.0.1",
            "X-Real-IP": "127.0.0.1",
            "X-Forwarded-Host": "localhost",
            "X-Custom-IP-Authorization": "127.0.0.1",
            "True-Client-IP": "127.0.0.1",
            "Cluster-Client-IP": "127.0.0.1",
            "X-ProxyUser-Ip": "127.0.0.1",
            "Via": "1.0 localhost",
            "Forwarded": "for=127.0.0.1;by=127.0.0.1;host=localhost",
        }
        new_headers = dict(headers)
        # Add 2-3 random bypass headers
        selected = random.sample(list(bypass_headers.items()), min(3, len(bypass_headers)))
        for k, v in selected:
            new_headers[k] = v
        return new_headers

    def _switch_content_type(self, headers: dict, body: Optional[dict]) -> Tuple[dict, Optional[dict]]:
        """Switch Content-Type to bypass content-type-based WAF rules."""
        new_headers = dict(headers)
        alternatives = [
            "application/x-www-form-urlencoded",
            "text/plain",
            "application/xml",
            "multipart/form-data",
            "application/json; charset=utf-8",
            "application/json;charset=UTF-8",
            "application/vnd.api+json",
            "application/csp-report",
        ]
        new_headers["Content-Type"] = random.choice(alternatives)
        return new_headers, body

    def _url_encode_path(self, url: str) -> str:
        """URL encode path segments."""
        parts = url.split("/")
        encoded = []
        for i, part in enumerate(parts):
            if i > 2 and part:  # Skip protocol and host
                encoded.append(urllib.parse.quote(part))
            else:
                encoded.append(part)
        return "/".join(encoded)

    def _double_url_encode_path(self, url: str) -> str:
        """Double URL encode path segments."""
        parts = url.split("/")
        encoded = []
        for i, part in enumerate(parts):
            if i > 2 and part:
                encoded.append(urllib.parse.quote(urllib.parse.quote(part)))
            else:
                encoded.append(part)
        return "/".join(encoded)

    def _unicode_encode_path(self, url: str) -> str:
        """Apply Unicode normalization bypass."""
        replacements = {
            "/": "%c0%af",
            ".": "%c0%ae",
            "-": "%c0%ad",
        }
        result = url
        for char, replacement in replacements.items():
            if random.random() > 0.5:
                result = result.replace(char, replacement, 1)
        return result

    def _null_byte_path(self, url: str) -> str:
        """Insert null bytes for bypass."""
        return url + "%00"

    def _path_normalization(self, url: str) -> str:
        """Path normalization tricks."""
        tricks = [
            lambda u: u.replace("/api/", "/./api/"),
            lambda u: u.replace("/api/", "//api/"),
            lambda u: u.replace("/api/", "/api;/"),
            lambda u: u + "/",
            lambda u: u + "/.",
            lambda u: u.replace("/", "/%2e/", 1) if "/api" in u else u,
        ]
        return random.choice(tricks)(url)

    def _parameter_pollution(self, params: Optional[dict]) -> Optional[dict]:
        """HTTP Parameter Pollution."""
        if not params:
            return params
        new_params = dict(params)
        # Duplicate a random parameter with a different value
        if new_params:
            key = random.choice(list(new_params.keys()))
            new_params[f"{key}[]"] = new_params[key]
        return new_params

    def _json_unicode_escape(self, body: Optional[dict]) -> Optional[dict]:
        """Apply Unicode escapes inside JSON values."""
        if not body or not isinstance(body, dict):
            return body
        # This returns the same dict — actual unicode escaping happens at serialization
        return body

    def _case_variation(self, url: str) -> str:
        """Randomize case in path segments."""
        return self._random_case(url)

    def _whitespace_variation(self, body: Optional[dict]) -> Optional[dict]:
        """Not applicable to dict bodies; used in raw payloads."""
        return body

    def _comment_injection(self, body: Optional[dict]) -> Optional[dict]:
        """Not applicable to dict bodies; used in raw payloads."""
        return body

    def _chunked_encoding(self, headers: dict) -> dict:
        """Add Transfer-Encoding: chunked header."""
        new_headers = dict(headers)
        new_headers["Transfer-Encoding"] = "chunked"
        return new_headers

    # -------------------------------------------------------------------------
    # Utility methods
    # -------------------------------------------------------------------------

    @staticmethod
    def _to_unicode_escapes(s: str) -> str:
        """Convert string to unicode escape sequences."""
        return "".join(f"\\u{ord(c):04x}" for c in s)

    @staticmethod
    def _random_case(s: str) -> str:
        """Randomize character case."""
        return "".join(c.upper() if random.random() > 0.5 else c.lower() for c in s)

    @staticmethod
    def _html_entity_encode(s: str) -> str:
        """Convert to HTML entity encoding."""
        return "".join(f"&#{ord(c)};" for c in s)

    @classmethod
    def get_ua_rotation(cls) -> str:
        """Return a random User-Agent for fingerprint evasion."""
        agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
            "Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Edge/120.0.0.0",
            "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
            "APIHound/2.0 (Security Research)",
            "PostmanRuntime/7.36.0",
            "curl/8.4.0",
        ]
        return random.choice(agents)
