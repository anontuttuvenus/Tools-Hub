#!/usr/bin/env python3
"""
APIHound v2.0 — OWASP API Security Top 10 Scanner
CLI entry point.

Usage:
  python apihound.py --spec https://target.com/api/openapi.json --auth "Bearer TOKEN"
  python apihound.py --target https://target.com/api --crawl --fuzz --lab-mode
  python apihound.py --spec spec.yaml --checks api1,api2,injection --waf-bypass
"""
import sys
import os

# Ensure project root is on sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import click
from core.config import ScanConfig, setup_logging
from core.scanner import Scanner
from core.reporter import Reporter


@click.command()
@click.option("--spec", default="", help="Path or URL to OpenAPI/Swagger spec (JSON or YAML)")
@click.option("--target", default="", help="Base URL for crawl/fuzz mode")
@click.option("--auth", default="", help="Authorization header value (e.g., 'Bearer TOKEN')")
@click.option("--auth-cookie", default="", help="Cookie-based auth string")
@click.option("--checks", default="all", help="Comma-separated check IDs (default: all)")
@click.option("--crawl", is_flag=True, help="Enable endpoint crawling")
@click.option("--fuzz", is_flag=True, help="Enable parameter/path fuzzing")
@click.option("--waf-bypass", is_flag=True, help="Enable WAF evasion mode")
@click.option("--proxy", default="", help="HTTP/SOCKS proxy (e.g., http://127.0.0.1:8080)")
@click.option("--rate-limit", default=10.0, type=float, help="Requests per second (default: 10)")
@click.option("--delay", default=0, type=int, help="Fixed delay between requests in ms")
@click.option("--timeout", default=15, type=int, help="Request timeout in seconds")
@click.option("--threads", default=5, type=int, help="Concurrent workers")
@click.option("--output", default="reports", help="Output directory for reports")
@click.option("--format", "report_format", default="html,json", help="Report formats: html, json, or both")
@click.option("--lab-mode", is_flag=True, help="Relaxed thresholds for vulnerable test labs")
@click.option("--verbose", is_flag=True, help="Verbose output")
@click.option("--user-id", default="", help="Known user ID for BOLA testing")
@click.option("--user-id-other", default="", help="Other user's ID for BOLA comparison")
@click.option("--no-verify-ssl", is_flag=True, help="Disable SSL certificate verification")
def main(
    spec, target, auth, auth_cookie, checks, crawl, fuzz, waf_bypass,
    proxy, rate_limit, delay, timeout, threads, output, report_format,
    lab_mode, verbose, user_id, user_id_other, no_verify_ssl,
):
    """
    APIHound v2.0 — OWASP API Security Top 10 Scanner

    Automated API penetration testing aligned with OWASP API Security Top 10 (2023).
    For authorized testing only.
    """
    logger = setup_logging(verbose)

    if not spec and not target:
        click.echo("Error: Provide --spec or --target (or both).", err=True)
        sys.exit(1)

    config = ScanConfig(
        target_url=target,
        spec_path=spec,
        auth_header=auth,
        auth_cookie=auth_cookie,
        checks=[c.strip() for c in checks.split(",")],
        crawl=crawl,
        fuzz=fuzz,
        lab_mode=lab_mode,
        proxy=proxy,
        timeout=timeout,
        rate_limit=rate_limit,
        delay_ms=delay,
        threads=threads,
        waf_bypass=waf_bypass,
        user_id=user_id,
        user_id_other=user_id_other,
        output_dir=output,
        report_formats=[f.strip() for f in report_format.split(",")],
        verbose=verbose,
        verify_ssl=not no_verify_ssl,
    )

    # Print banner
    click.echo("""
    ╔══════════════════════════════════════════╗
    ║     🐕 APIHound v2.0                    ║
    ║     OWASP API Security Top 10 Scanner   ║
    ╚══════════════════════════════════════════╝
    """)
    click.echo(f"  Target:     {target or spec}")
    click.echo(f"  Checks:     {checks}")
    click.echo(f"  WAF Bypass: {'ON' if waf_bypass else 'OFF'}")
    click.echo(f"  Rate Limit: {rate_limit} req/s")
    click.echo(f"  Lab Mode:   {'ON' if lab_mode else 'OFF'}")
    click.echo()

    # Run scan
    scanner = Scanner(config)
    try:
        findings = scanner.run()

        # Generate reports
        reporter = Reporter(output)
        report_files = reporter.generate(
            findings,
            scanner.get_scan_metadata(),
            config.report_formats,
        )

        click.echo()
        for f in report_files:
            click.echo(f"  Report: {f}")

        # Exit code based on findings
        critical_or_high = sum(1 for f in findings if f.severity in ("CRITICAL", "HIGH"))
        sys.exit(1 if critical_or_high > 0 else 0)

    except KeyboardInterrupt:
        click.echo("\n[!] Scan interrupted by user.")
        sys.exit(130)
    finally:
        scanner.close()


if __name__ == "__main__":
    main()
