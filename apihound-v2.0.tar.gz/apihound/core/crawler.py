"""
APIHound — API endpoint crawler and path/parameter fuzzer.
Discovers endpoints via common path brute-forcing and response analysis.
"""
import logging
import re
from typing import Optional
from urllib.parse import urljoin, urlparse
from core.config import ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint, APIParameter
from wordlists.wordlist_manager import WordlistManager

logger = logging.getLogger("apihound.crawler")


class APICrawler:
    """Discover API endpoints via path brute-force, version enumeration, and response analysis."""

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.wl = WordlistManager()
        self.discovered: list = []
        self._seen_paths: set = set()

    def crawl(self, base_url: str) -> list:
        """Run full endpoint discovery. Returns list of APIEndpoint."""
        base_url = base_url.rstrip("/")
        logger.info(f"Starting API crawl on {base_url}")

        # Phase 1: Discover base paths (spec files, common roots)
        self._discover_spec_files(base_url)
        self._discover_common_roots(base_url)

        # Phase 2: Version enumeration
        self._discover_api_versions(base_url)

        # Phase 3: Endpoint brute-force
        self._brute_force_endpoints(base_url)

        # Phase 4: Fuzz discovered endpoints for methods
        if self.config.fuzz:
            self._fuzz_methods()

        logger.info(f"Crawl complete: {len(self.discovered)} endpoints found")
        return self.discovered

    def _discover_spec_files(self, base_url: str):
        """Look for OpenAPI/Swagger spec files."""
        spec_paths = [
            "/openapi.json", "/openapi.yaml", "/swagger.json", "/swagger.yaml",
            "/api-docs", "/api-docs.json", "/v2/api-docs", "/v3/api-docs",
            "/docs", "/api/docs", "/api/swagger.json", "/api/openapi.json",
            "/.well-known/openapi.json", "/api/v1/swagger.json",
            "/api/v2/swagger.json", "/api/v3/openapi.json",
            "/swagger-ui.html", "/swagger-ui/", "/redoc",
            "/graphql", "/graphiql", "/playground", "/api/graphql",
        ]
        for path in spec_paths:
            url = f"{base_url}{path}"
            resp = self.client.get(url)
            if resp and resp.status_code == 200:
                content_len = len(resp.text)
                if content_len > 50:  # Non-trivial response
                    logger.info(f"Found spec/docs endpoint: {path} ({content_len} bytes)")
                    self._add_endpoint(path, "GET", base_url)

    def _discover_common_roots(self, base_url: str):
        """Probe common API root paths."""
        roots = [
            "/api", "/api/v1", "/api/v2", "/api/v3",
            "/rest", "/rest/v1", "/rest/v2",
            "/v1", "/v2", "/v3",
            "/internal", "/admin/api", "/backend",
            "/service", "/services", "/rpc",
        ]
        for path in roots:
            url = f"{base_url}{path}"
            resp = self.client.get(url)
            if resp and resp.status_code in (200, 301, 302, 401, 403, 405):
                logger.debug(f"API root found: {path} -> {resp.status_code}")
                self._add_endpoint(path, "GET", base_url)

    def _discover_api_versions(self, base_url: str):
        """Enumerate API versions for inventory management (API9) checking."""
        version_prefixes = self.wl.get_api_versions()
        for prefix in version_prefixes[:30]:  # Cap to avoid excessive requests
            url = f"{base_url}{prefix}"
            resp = self.client.get(url)
            if resp and resp.status_code in (200, 301, 302, 401, 403):
                logger.debug(f"API version endpoint: {prefix} -> {resp.status_code}")
                self._add_endpoint(prefix, "GET", base_url)

    def _brute_force_endpoints(self, base_url: str):
        """Brute-force common API endpoint paths."""
        endpoints = self.wl.get_api_endpoints()
        # Build candidate paths with discovered API roots
        roots = [""]
        for ep in self.discovered:
            if ep.path.startswith(("/api", "/rest", "/v")):
                roots.append(ep.path)

        tested = set()
        for root in roots[:5]:  # Limit root combinations
            for ep_path in endpoints[:200]:  # Cap endpoint list
                full_path = f"{root}/{ep_path}".replace("//", "/")
                if full_path in tested:
                    continue
                tested.add(full_path)

                url = f"{base_url}{full_path}"
                resp = self.client.get(url)
                if resp and resp.status_code in (200, 201, 401, 403, 405):
                    logger.debug(f"Endpoint found: {full_path} -> {resp.status_code}")
                    self._add_endpoint(full_path, "GET", base_url)

                    # If 405, try POST
                    if resp.status_code == 405:
                        resp2 = self.client.post(url, json_body={})
                        if resp2 and resp2.status_code != 405:
                            self._add_endpoint(full_path, "POST", base_url)

    def _fuzz_methods(self):
        """For each discovered endpoint, test additional HTTP methods."""
        methods = ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"]
        for ep in list(self.discovered):
            for method in methods:
                if method == ep.method:
                    continue
                resp = self.client.request(method, ep.full_url, json_body={} if method in ("POST", "PUT", "PATCH") else None)
                if resp and resp.status_code not in (404, 405, 501):
                    self._add_endpoint(ep.path, method, self.config.target_url)

    def _add_endpoint(self, path: str, method: str, base_url: str):
        """Add endpoint if not already discovered."""
        key = f"{method}:{path}"
        if key in self._seen_paths:
            return
        self._seen_paths.add(key)

        # Detect path parameters
        params = []
        for match in re.finditer(r'\{(\w+)\}', path):
            params.append(APIParameter(
                name=match.group(1), location="path", param_type="string", required=True
            ))

        ep = APIEndpoint(
            path=path,
            method=method,
            full_url=f"{base_url.rstrip('/')}{path}",
            parameters=params,
        )
        self.discovered.append(ep)

    def extract_endpoints_from_response(self, body: str) -> list:
        """Extract potential API paths from response body (links, references)."""
        paths = set()
        # JSON string values that look like API paths
        for match in re.finditer(r'"(/[a-zA-Z0-9_/\-{}]+)"', body):
            path = match.group(1)
            if len(path) > 3 and not path.endswith(('.js', '.css', '.png', '.jpg')):
                paths.add(path)
        # href/action/url patterns
        for match in re.finditer(r'(?:href|action|url)["\s:=]+["\'](/[a-zA-Z0-9_/\-]+)', body):
            paths.add(match.group(1))
        return list(paths)
