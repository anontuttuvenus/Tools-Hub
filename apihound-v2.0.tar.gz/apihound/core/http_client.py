"""
APIHound — HTTP client engine with proxy support, retries, and WAF evasion hooks.
"""
import httpx
import logging
import time
from typing import Optional
from core.config import ScanConfig, RateLimiter

logger = logging.getLogger("apihound.http")


class HTTPClient:
    """Wrapper around httpx with rate limiting, proxy, and WAF evasion."""

    def __init__(self, config: ScanConfig, waf_engine=None):
        self.config = config
        self.waf_engine = waf_engine
        self.rate_limiter = RateLimiter(config.rate_limit, config.delay_ms)
        self._stats = {"requests": 0, "errors": 0, "waf_blocks": 0}

        transport_kwargs = {}
        if config.proxy:
            transport_kwargs["proxy"] = config.proxy

        self.client = httpx.Client(
            timeout=httpx.Timeout(config.timeout),
            verify=config.verify_ssl,
            follow_redirects=False,
            **transport_kwargs,
        )

    def request(
        self,
        method: str,
        url: str,
        headers: Optional[dict] = None,
        params: Optional[dict] = None,
        json_body=None,
        data=None,
        raw_body: Optional[str] = None,
        follow_redirects: bool = False,
        apply_waf_bypass: bool = False,
    ) -> Optional[httpx.Response]:
        """
        Send a single HTTP request with rate limiting and optional WAF evasion.
        Returns httpx.Response or None on error.
        """
        self.rate_limiter.wait()

        merged_headers = self.config.get_headers()
        if headers:
            merged_headers.update(headers)

        # Apply WAF bypass transformations if enabled
        if apply_waf_bypass and self.waf_engine and self.config.waf_bypass:
            method, url, merged_headers, params, json_body = (
                self.waf_engine.transform_request(
                    method, url, merged_headers, params, json_body
                )
            )

        try:
            kwargs = {
                "method": method.upper(),
                "url": url,
                "headers": merged_headers,
                "follow_redirects": follow_redirects,
            }
            if params:
                kwargs["params"] = params
            if json_body is not None:
                kwargs["json"] = json_body
            elif data is not None:
                kwargs["data"] = data
            elif raw_body is not None:
                kwargs["content"] = raw_body

            resp = self.client.request(**kwargs)
            self._stats["requests"] += 1

            # Detect WAF blocks (common patterns)
            if resp.status_code in (403, 406, 429, 503):
                block_sigs = [
                    "access denied", "blocked", "waf", "firewall",
                    "rate limit", "captcha", "challenge",
                ]
                body_lower = resp.text[:500].lower()
                if any(sig in body_lower for sig in block_sigs):
                    self._stats["waf_blocks"] += 1
                    logger.debug(f"Possible WAF block on {method} {url} -> {resp.status_code}")

            return resp

        except httpx.TimeoutException:
            logger.debug(f"Timeout: {method} {url}")
            self._stats["errors"] += 1
            return None
        except httpx.RequestError as e:
            logger.debug(f"Request error: {method} {url} -> {e}")
            self._stats["errors"] += 1
            return None

    def get(self, url, **kwargs) -> Optional[httpx.Response]:
        return self.request("GET", url, **kwargs)

    def post(self, url, **kwargs) -> Optional[httpx.Response]:
        return self.request("POST", url, **kwargs)

    def put(self, url, **kwargs) -> Optional[httpx.Response]:
        return self.request("PUT", url, **kwargs)

    def delete(self, url, **kwargs) -> Optional[httpx.Response]:
        return self.request("DELETE", url, **kwargs)

    def patch(self, url, **kwargs) -> Optional[httpx.Response]:
        return self.request("PATCH", url, **kwargs)

    def options(self, url, **kwargs) -> Optional[httpx.Response]:
        return self.request("OPTIONS", url, **kwargs)

    @property
    def stats(self) -> dict:
        return dict(self._stats)

    def close(self):
        self.client.close()

    def build_raw_request(self, method: str, url: str, headers: dict, body: str = "") -> str:
        """Reconstruct raw HTTP request for reporting."""
        from urllib.parse import urlparse
        parsed = urlparse(url)
        path = parsed.path or "/"
        if parsed.query:
            path += f"?{parsed.query}"
        lines = [f"{method.upper()} {path} HTTP/1.1"]
        lines.append(f"Host: {parsed.netloc}")
        for k, v in headers.items():
            lines.append(f"{k}: {v}")
        lines.append("")
        if body:
            lines.append(body)
        return "\r\n".join(lines)

    def build_raw_response(self, resp: httpx.Response, max_body: int = 1500) -> str:
        """Reconstruct raw HTTP response for reporting."""
        lines = [f"HTTP/{resp.http_version} {resp.status_code} {resp.reason_phrase or ''}"]
        for k, v in resp.headers.items():
            lines.append(f"{k}: {v}")
        lines.append("")
        body = resp.text[:max_body]
        if len(resp.text) > max_body:
            body += "\n... [truncated]"
        lines.append(body)
        return "\r\n".join(lines)
