"""
APIHound — OpenAPI / Swagger specification parser.
Extracts endpoints, parameters, schemas, and authentication requirements.
"""
import json
import logging
import yaml
from typing import Optional
from dataclasses import dataclass, field
from urllib.parse import urljoin

logger = logging.getLogger("apihound.parser")


@dataclass
class APIParameter:
    """Single API parameter."""
    name: str
    location: str  # query, header, path, cookie, body
    param_type: str = "string"
    required: bool = False
    example: str = ""
    enum: list = field(default_factory=list)


@dataclass
class APIEndpoint:
    """Single API endpoint extracted from spec or crawling."""
    path: str
    method: str
    full_url: str = ""
    summary: str = ""
    parameters: list = field(default_factory=list)  # List[APIParameter]
    request_body_schema: dict = field(default_factory=dict)
    response_schemas: dict = field(default_factory=dict)
    security: list = field(default_factory=list)
    tags: list = field(default_factory=list)
    content_type: str = "application/json"

    def has_path_params(self) -> bool:
        return "{" in self.path

    def has_id_params(self) -> bool:
        """Check if endpoint has object ID parameters (BOLA targets)."""
        id_patterns = ["id", "uid", "user_id", "userId", "account_id", "order_id",
                       "item_id", "resource_id", "uuid", "pk", "slug"]
        for p in self.parameters:
            if any(pat in p.name.lower() for pat in id_patterns):
                return True
        # Also check path for {id}-style params
        return any(pat in self.path.lower() for pat in ["{id", "{user", "{account", "{order"])


class OpenAPIParser:
    """Parse OpenAPI 2.0 (Swagger) and 3.x specifications."""

    def __init__(self, base_url: str = ""):
        self.base_url = base_url.rstrip("/")
        self.endpoints: list = []
        self.security_schemes: dict = {}
        self.servers: list = []
        self.schemas: dict = {}

    def parse(self, spec_data: str) -> list:
        """Parse spec from string (JSON or YAML). Returns list of APIEndpoint."""
        try:
            spec = json.loads(spec_data)
        except (json.JSONDecodeError, ValueError):
            spec = yaml.safe_load(spec_data)

        if not isinstance(spec, dict):
            logger.error("Invalid spec format")
            return []

        # Detect version
        if spec.get("openapi", "").startswith("3"):
            return self._parse_openapi3(spec)
        elif spec.get("swagger", "").startswith("2"):
            return self._parse_swagger2(spec)
        else:
            logger.warning("Unknown spec version, attempting OpenAPI 3 parse")
            return self._parse_openapi3(spec)

    def parse_file(self, path: str) -> list:
        """Parse spec from file path."""
        with open(path) as f:
            return self.parse(f.read())

    def _parse_openapi3(self, spec: dict) -> list:
        """Parse OpenAPI 3.x spec."""
        # Extract servers
        for server in spec.get("servers", []):
            self.servers.append(server.get("url", ""))
        if not self.base_url and self.servers:
            self.base_url = self.servers[0].rstrip("/")

        # Extract security schemes
        components = spec.get("components", {})
        self.security_schemes = components.get("securitySchemes", {})
        self.schemas = components.get("schemas", {})

        # Extract endpoints
        paths = spec.get("paths", {})
        for path, methods in paths.items():
            if not isinstance(methods, dict):
                continue
            for method, details in methods.items():
                if method.lower() in ("get", "post", "put", "delete", "patch", "head", "options"):
                    ep = self._build_endpoint_v3(path, method, details)
                    self.endpoints.append(ep)

        logger.info(f"Parsed {len(self.endpoints)} endpoints from OpenAPI 3.x spec")
        return self.endpoints

    def _parse_swagger2(self, spec: dict) -> list:
        """Parse Swagger 2.0 spec."""
        host = spec.get("host", "")
        base_path = spec.get("basePath", "")
        schemes = spec.get("schemes", ["https"])
        if not self.base_url and host:
            self.base_url = f"{schemes[0]}://{host}{base_path}".rstrip("/")

        self.security_schemes = spec.get("securityDefinitions", {})
        self.schemas = spec.get("definitions", {})

        paths = spec.get("paths", {})
        for path, methods in paths.items():
            if not isinstance(methods, dict):
                continue
            for method, details in methods.items():
                if method.lower() in ("get", "post", "put", "delete", "patch", "head", "options"):
                    ep = self._build_endpoint_v2(path, method, details)
                    self.endpoints.append(ep)

        logger.info(f"Parsed {len(self.endpoints)} endpoints from Swagger 2.0 spec")
        return self.endpoints

    def _build_endpoint_v3(self, path: str, method: str, details: dict) -> APIEndpoint:
        """Build APIEndpoint from OpenAPI 3.x operation."""
        ep = APIEndpoint(
            path=path,
            method=method.upper(),
            full_url=f"{self.base_url}{path}",
            summary=details.get("summary", details.get("description", ""))[:200],
            tags=details.get("tags", []),
            security=details.get("security", []),
        )

        # Parameters (query, path, header, cookie)
        for param in details.get("parameters", []):
            schema = param.get("schema", {})
            ep.parameters.append(APIParameter(
                name=param.get("name", ""),
                location=param.get("in", "query"),
                param_type=schema.get("type", "string"),
                required=param.get("required", False),
                example=str(param.get("example", schema.get("example", ""))),
                enum=schema.get("enum", []),
            ))

        # Request body
        req_body = details.get("requestBody", {})
        content = req_body.get("content", {})
        for ct, ct_details in content.items():
            ep.content_type = ct
            ep.request_body_schema = ct_details.get("schema", {})
            break  # take first content type

        # Response schemas
        for code, resp in details.get("responses", {}).items():
            resp_content = resp.get("content", {})
            for ct, ct_details in resp_content.items():
                ep.response_schemas[code] = ct_details.get("schema", {})
                break

        return ep

    def _build_endpoint_v2(self, path: str, method: str, details: dict) -> APIEndpoint:
        """Build APIEndpoint from Swagger 2.0 operation."""
        ep = APIEndpoint(
            path=path,
            method=method.upper(),
            full_url=f"{self.base_url}{path}",
            summary=details.get("summary", "")[:200],
            tags=details.get("tags", []),
            security=details.get("security", []),
        )

        for param in details.get("parameters", []):
            if param.get("in") == "body":
                ep.request_body_schema = param.get("schema", {})
            else:
                ep.parameters.append(APIParameter(
                    name=param.get("name", ""),
                    location=param.get("in", "query"),
                    param_type=param.get("type", "string"),
                    required=param.get("required", False),
                    example=str(param.get("example", "")),
                    enum=param.get("enum", []),
                ))

        consumes = details.get("consumes", ["application/json"])
        if consumes:
            ep.content_type = consumes[0]

        return ep

    def get_bola_candidates(self) -> list:
        """Return endpoints likely vulnerable to BOLA (have ID parameters)."""
        return [ep for ep in self.endpoints if ep.has_id_params()]

    def get_admin_candidates(self) -> list:
        """Return endpoints likely to be admin/privileged functions."""
        admin_patterns = [
            "admin", "manage", "config", "setting", "role", "permission",
            "user/create", "user/delete", "user/update", "user/list",
            "system", "internal", "debug", "console", "dashboard",
        ]
        results = []
        for ep in self.endpoints:
            path_lower = ep.path.lower()
            if any(p in path_lower for p in admin_patterns):
                results.append(ep)
        return results
