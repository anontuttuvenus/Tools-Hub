"""
APIHound — Report Generator
Produces HTML (Jinja2) and JSON reports with PoC request/response.
"""
import json
import logging
import os
from datetime import datetime
from typing import List
from jinja2 import Environment, FileSystemLoader
from core.config import Finding

logger = logging.getLogger("apihound.reporter")

# Template directory (relative to project root)
_TEMPLATE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "templates")


class Reporter:
    """Generate scan reports in multiple formats."""

    def __init__(self, output_dir: str = "reports"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def generate(
        self,
        findings: List[Finding],
        metadata: dict,
        formats: List[str] = None,
    ) -> List[str]:
        """
        Generate reports in requested formats.
        Returns list of output file paths.
        """
        formats = formats or ["html", "json"]
        outputs = []
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        if "json" in formats:
            path = self._generate_json(findings, metadata, timestamp)
            outputs.append(path)

        if "html" in formats:
            path = self._generate_html(findings, metadata, timestamp)
            outputs.append(path)

        return outputs

    def _generate_json(self, findings: List[Finding], metadata: dict, timestamp: str) -> str:
        """Generate JSON report."""
        report = {
            "metadata": metadata,
            "scan_date": datetime.now().isoformat(),
            "summary": self._build_summary(findings),
            "findings": [f.to_dict() for f in findings],
        }

        path = os.path.join(self.output_dir, f"apihound_report_{timestamp}.json")
        with open(path, "w") as f:
            json.dump(report, f, indent=2, default=str)

        logger.info(f"JSON report: {path}")
        return path

    def _generate_html(self, findings: List[Finding], metadata: dict, timestamp: str) -> str:
        """Generate HTML report using Jinja2 template."""
        env = Environment(loader=FileSystemLoader(_TEMPLATE_DIR), autoescape=True)
        template = env.get_template("report.html")

        counts = self._build_summary(findings)
        html = template.render(
            meta=metadata,
            counts=counts,
            findings=[f.to_dict() for f in findings],
            scan_date=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )

        path = os.path.join(self.output_dir, f"apihound_report_{timestamp}.html")
        with open(path, "w") as f:
            f.write(html)

        logger.info(f"HTML report: {path}")
        return path

    def _build_summary(self, findings: List[Finding]) -> dict:
        """Count findings by severity."""
        counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        for f in findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1
        return counts
