"""
APIHound — API3:2023 Broken Object Property Level Authorization
Combines Mass Assignment and Excessive Data Exposure testing.
"""
import json
import logging
import re
from typing import List
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint
from payloads.payload_db import PayloadDB

logger = logging.getLogger("apihound.checks.api3")


class PropertyAuthCheck:
    """Test for mass assignment and excessive data exposure."""

    CHECK_ID = "API3-PROPERTY"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xa3-broken-object-property-level-authorization/"

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        logger.info(f"[{self.CHECK_ID}] Starting property-level authorization checks")

        for ep in endpoints:
            # Excessive data exposure — check GET responses
            if ep.method == "GET":
                self._test_excessive_data(ep)

            # Mass assignment — check PUT/POST/PATCH endpoints
            if ep.method in ("POST", "PUT", "PATCH"):
                self._test_mass_assignment(ep)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    def _test_excessive_data(self, ep: APIEndpoint):
        """Check if API responses leak sensitive fields."""
        resp = self.client.get(ep.full_url)
        if not resp or resp.status_code != 200:
            return

        body = resp.text
        sensitive_found = []

        for pattern in PayloadDB.SENSITIVE_DATA_PATTERNS:
            matches = re.findall(pattern, body, re.IGNORECASE)
            if matches:
                sensitive_found.extend(matches[:3])

        # Also check for common sensitive field names in JSON keys
        try:
            data = resp.json()
            sensitive_keys = self._find_sensitive_keys(data)
            if sensitive_keys:
                sensitive_found.extend(sensitive_keys)
        except (json.JSONDecodeError, ValueError):
            pass

        if sensitive_found:
            self.findings.append(Finding(
                check_id=self.CHECK_ID,
                severity="HIGH",
                title=f"Excessive data exposure — {ep.path}",
                description="API response contains sensitive fields that should not be exposed to the client.",
                endpoint=ep.full_url,
                method="GET",
                evidence=f"Sensitive fields found: {sensitive_found[:10]}",
                response_code=resp.status_code,
                confidence="Medium",
                remediation=(
                    "Implement response filtering. Only return fields the client needs. "
                    "Never expose password hashes, tokens, internal IDs, or PII in responses."
                ),
                references=[self.OWASP_REF],
                cvss=6.5,
                tags=["data-exposure", "sensitive-data", "pii"],
            ))

    def _test_mass_assignment(self, ep: APIEndpoint):
        """Test if extra fields in request body are accepted (privilege escalation)."""
        # First, send a baseline request to see what's accepted
        baseline_body = self._build_baseline_body(ep)

        for field_name in PayloadDB.MASS_ASSIGNMENT_FIELDS[:20]:
            for value in PayloadDB.MASS_ASSIGNMENT_VALUES["boolean_true"][:2]:
                test_body = {**baseline_body, field_name: value}
                resp = self.client.request(ep.method, ep.full_url, json_body=test_body)

                if resp and resp.status_code in (200, 201):
                    try:
                        data = resp.json()
                        # Check if the injected field appears in response
                        resp_str = json.dumps(data).lower()
                        if field_name.lower() in resp_str:
                            self.findings.append(Finding(
                                check_id=self.CHECK_ID,
                                severity="HIGH",
                                title=f"Mass assignment — {ep.path} ({field_name})",
                                description=(
                                    f"The field '{field_name}' was accepted in the request body "
                                    f"and reflected in the response. This may allow privilege escalation."
                                ),
                                endpoint=ep.full_url,
                                method=ep.method,
                                evidence=f"Injected {field_name}={value}, field appeared in response.",
                                response_code=resp.status_code,
                                confidence="Medium",
                                remediation=(
                                    "Use allowlists for accepted fields. Never bind request body "
                                    "directly to internal models. Explicitly define which properties "
                                    "can be modified by the client."
                                ),
                                references=[self.OWASP_REF],
                                cvss=7.3,
                                tags=["mass-assignment", "privilege-escalation"],
                            ))
                            return  # One finding per endpoint
                    except (json.JSONDecodeError, ValueError):
                        pass

    def _build_baseline_body(self, ep: APIEndpoint) -> dict:
        """Build a minimal valid request body from schema or common patterns."""
        if ep.request_body_schema:
            return self._schema_to_sample(ep.request_body_schema)

        # Guess based on endpoint path
        path_lower = ep.path.lower()
        if "user" in path_lower or "profile" in path_lower:
            return {"name": "testuser", "email": "test@test.com"}
        if "post" in path_lower or "comment" in path_lower:
            return {"title": "test", "content": "test content"}
        if "order" in path_lower:
            return {"item_id": "1", "quantity": 1}
        return {"name": "test", "value": "test"}

    def _schema_to_sample(self, schema: dict) -> dict:
        """Generate sample request body from OpenAPI schema."""
        result = {}
        props = schema.get("properties", {})
        for name, prop in props.items():
            ptype = prop.get("type", "string")
            if ptype == "string":
                result[name] = prop.get("example", "test")
            elif ptype == "integer":
                result[name] = prop.get("example", 1)
            elif ptype == "boolean":
                result[name] = prop.get("example", True)
            elif ptype == "number":
                result[name] = prop.get("example", 1.0)
            elif ptype == "array":
                result[name] = []
            elif ptype == "object":
                result[name] = {}
        return result

    def _find_sensitive_keys(self, data, prefix="", depth=0) -> list:
        """Recursively find sensitive key names in JSON response."""
        if depth > 5:
            return []
        sensitive_names = {
            "password", "passwd", "pwd", "secret", "token", "api_key", "apiKey",
            "access_token", "refresh_token", "private_key", "privateKey",
            "ssn", "social_security", "credit_card", "creditCard", "card_number",
            "cvv", "pin", "salary", "bank_account", "routing_number",
            "password_hash", "passwordHash", "salt", "mfa_secret",
        }
        found = []

        if isinstance(data, dict):
            for key, val in data.items():
                full_key = f"{prefix}.{key}" if prefix else key
                if key.lower() in sensitive_names:
                    found.append(full_key)
                if isinstance(val, (dict, list)):
                    found.extend(self._find_sensitive_keys(val, full_key, depth + 1))
        elif isinstance(data, list) and data:
            found.extend(self._find_sensitive_keys(data[0], prefix, depth + 1))

        return found
