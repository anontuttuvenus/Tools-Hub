"""
APIHound — API6:2023 Unrestricted Access to Sensitive Business Flows
Detects missing anti-automation controls on business-critical endpoints.
"""
import logging
import time
from typing import List
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint

logger = logging.getLogger("apihound.checks.api6")


class BusinessFlowCheck:
    CHECK_ID = "API6-BUSINESS"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xa6-unrestricted-access-to-sensitive-business-flows/"

    SENSITIVE_FLOW_PATTERNS = [
        "purchase", "buy", "checkout", "order", "pay", "payment",
        "transfer", "send", "withdraw", "deposit",
        "register", "signup", "subscribe", "invite",
        "vote", "like", "follow", "comment", "post",
        "coupon", "promo", "redeem", "claim",
        "reserve", "book", "appointment",
        "verify", "confirm", "approve",
    ]

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        logger.info(f"[{self.CHECK_ID}] Starting business flow checks")

        sensitive_eps = self._find_sensitive_flows(endpoints)
        logger.info(f"[{self.CHECK_ID}] Found {len(sensitive_eps)} sensitive business flow endpoints")

        for ep in sensitive_eps:
            self._test_automation_resistance(ep)
            self._test_missing_captcha(ep)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    def _find_sensitive_flows(self, endpoints: List[APIEndpoint]) -> List[APIEndpoint]:
        """Identify endpoints representing sensitive business operations."""
        results = []
        for ep in endpoints:
            path_lower = ep.path.lower()
            if any(pat in path_lower for pat in self.SENSITIVE_FLOW_PATTERNS):
                if ep.method in ("POST", "PUT", "PATCH"):
                    results.append(ep)
        return results

    def _test_automation_resistance(self, ep: APIEndpoint):
        """Test if sensitive endpoint can be called rapidly (bot-like)."""
        success_count = 0
        body = {"test": True}  # Minimal body

        for _ in range(10):
            resp = self.client.post(ep.full_url, json_body=body)
            if resp and resp.status_code in (200, 201, 400, 422):
                success_count += 1
            elif resp and resp.status_code == 429:
                return  # Anti-automation in place

        if success_count >= 9:
            self.findings.append(Finding(
                check_id=self.CHECK_ID,
                severity="MEDIUM",
                title=f"No anti-automation on business flow — {ep.path}",
                description=(
                    "Sensitive business endpoint accepts rapid automated requests "
                    "without CAPTCHA, rate limiting, or anti-bot measures."
                ),
                endpoint=ep.full_url,
                method=ep.method,
                evidence=f"10 rapid requests all accepted ({success_count} non-429 responses).",
                confidence="Medium",
                remediation=(
                    "Implement anti-automation controls: CAPTCHA, rate limiting, "
                    "device fingerprinting, or step-up authentication for sensitive flows."
                ),
                references=[self.OWASP_REF],
                cvss=5.3,
                tags=["business-logic", "automation", "anti-bot"],
            ))

    def _test_missing_captcha(self, ep: APIEndpoint):
        """Check if response headers/body indicate CAPTCHA requirement."""
        resp = self.client.post(ep.full_url, json_body={})
        if not resp:
            return

        body_lower = resp.text.lower()
        captcha_indicators = ["captcha", "recaptcha", "hcaptcha", "turnstile", "challenge"]

        if not any(ind in body_lower for ind in captcha_indicators):
            # Also check response headers
            headers_lower = {k.lower(): v.lower() for k, v in resp.headers.items()}
            if not any(ind in str(headers_lower) for ind in captcha_indicators):
                # No CAPTCHA detected — this is informational
                pass  # Covered by automation resistance test above
