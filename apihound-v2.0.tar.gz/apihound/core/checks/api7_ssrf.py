"""
APIHound — API7:2023 Server Side Request Forgery (SSRF)
Tests URL parameters for SSRF via localhost, cloud metadata, and protocol smuggling.
"""
import logging
import re
from typing import List
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint
from payloads.payload_db import PayloadDB

logger = logging.getLogger("apihound.checks.api7")


class SSRFCheck:
    CHECK_ID = "API7-SSRF"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xa7-server-side-request-forgery/"

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        logger.info(f"[{self.CHECK_ID}] Starting SSRF checks")

        for ep in endpoints:
            self._test_query_params(ep)
            if ep.method in ("POST", "PUT", "PATCH"):
                self._test_body_params(ep)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    def _test_query_params(self, ep: APIEndpoint):
        """Test query parameters that accept URLs."""
        url_params = [p for p in ep.parameters if p.location == "query" and
                      p.name.lower() in PayloadDB.SSRF_PARAM_NAMES]

        for param in url_params:
            for payload in PayloadDB.SSRF_PAYLOADS[:15]:
                resp = self.client.get(ep.full_url, params={param.name: payload})
                if self._detect_ssrf(resp, payload):
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="CRITICAL" if "169.254" in payload else "HIGH",
                        title=f"SSRF via query param '{param.name}' — {ep.path}",
                        description=f"Server fetched attacker-controlled URL via parameter '{param.name}'.",
                        endpoint=ep.full_url,
                        method="GET",
                        evidence=f"Payload: {param.name}={payload} — response indicates server-side fetch.",
                        response_code=resp.status_code if resp else 0,
                        confidence="Medium",
                        remediation=(
                            "Validate and sanitize all user-supplied URLs. Use allowlists for "
                            "permitted domains. Block requests to internal/private IP ranges. "
                            "Disable unnecessary URL schemes (file://, gopher://, dict://)."
                        ),
                        references=[self.OWASP_REF],
                        cvss=9.1 if "169.254" in payload else 7.5,
                        tags=["ssrf", "cloud-metadata"] if "169.254" in payload else ["ssrf"],
                    ))
                    return  # One finding per param

    def _test_body_params(self, ep: APIEndpoint):
        """Test request body fields that may accept URLs."""
        for param_name in PayloadDB.SSRF_PARAM_NAMES[:10]:
            for payload in PayloadDB.SSRF_PAYLOADS[:10]:
                body = {param_name: payload}
                resp = self.client.request(ep.method, ep.full_url, json_body=body)
                if self._detect_ssrf(resp, payload):
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="CRITICAL" if "169.254" in payload else "HIGH",
                        title=f"SSRF via body param '{param_name}' — {ep.path}",
                        description=f"Server fetched attacker-controlled URL from request body field '{param_name}'.",
                        endpoint=ep.full_url,
                        method=ep.method,
                        evidence=f"Payload: {param_name}={payload}",
                        response_code=resp.status_code if resp else 0,
                        confidence="Medium",
                        remediation="Validate URLs server-side. Use allowlists. Block internal IP ranges.",
                        references=[self.OWASP_REF],
                        cvss=9.1 if "169.254" in payload else 7.5,
                        tags=["ssrf"],
                    ))
                    return

    def _detect_ssrf(self, resp, payload: str) -> bool:
        """Heuristic detection of successful SSRF."""
        if not resp:
            return False

        body = resp.text.lower()

        # Cloud metadata indicators
        if "169.254" in payload:
            metadata_sigs = [
                "ami-id", "instance-id", "security-credentials",
                "iam", "meta-data", "computemetadata", "instance/",
            ]
            if any(sig in body for sig in metadata_sigs):
                return True

        # Localhost indicators
        if "127.0.0.1" in payload or "localhost" in payload:
            local_sigs = [
                "root:", "/bin/", "uid=", "apache", "nginx",
                "welcome to", "index of", "directory listing",
            ]
            if any(sig in body for sig in local_sigs):
                return True

        # File read indicators
        if "file://" in payload:
            if "root:" in body or "nobody:" in body or "[extensions]" in body:
                return True

        # Time-based: unusually long response for internal fetch
        # (covered by timeout in client)

        # Response contains content that looks like it was fetched from the payload URL
        if resp.status_code == 200 and len(body) > 100:
            # Check if response differs significantly from a baseline error
            if "error" not in body and "not found" not in body:
                return False  # Conservative — avoid false positives

        return False
