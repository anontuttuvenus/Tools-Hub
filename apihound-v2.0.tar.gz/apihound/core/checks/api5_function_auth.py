"""
APIHound — API5:2023 Broken Function Level Authorization
Tests admin endpoint access, HTTP method tampering, privilege escalation.
"""
import logging
from typing import List
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint
from payloads.payload_db import PayloadDB

logger = logging.getLogger("apihound.checks.api5")


class FunctionAuthCheck:
    CHECK_ID = "API5-FUNCTION"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xa5-broken-function-level-authorization/"

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        logger.info(f"[{self.CHECK_ID}] Starting function-level authorization checks")

        # Phase 1: Probe privileged paths
        self._test_admin_endpoints()

        # Phase 2: HTTP method tampering on existing endpoints
        for ep in endpoints[:30]:
            self._test_method_tampering(ep)
            self._test_method_override(ep)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    def _test_admin_endpoints(self):
        """Probe admin/privileged paths with regular user credentials."""
        base = self.config.target_url.rstrip("/")

        for path in PayloadDB.PRIVILEGE_ESCALATION_PATHS:
            url = f"{base}{path}"
            resp = self.client.get(url)
            if not resp:
                continue

            if resp.status_code == 200 and len(resp.text) > 20:
                self.findings.append(Finding(
                    check_id=self.CHECK_ID,
                    severity="HIGH",
                    title=f"Admin endpoint accessible — {path}",
                    description="Privileged endpoint is accessible with regular user credentials.",
                    endpoint=url,
                    method="GET",
                    evidence=f"Got 200 OK with {len(resp.text)} bytes on admin path.",
                    response_code=200,
                    confidence="Medium",
                    remediation="Implement role-based access control. Deny access to admin functions for non-admin users.",
                    references=[self.OWASP_REF],
                    cvss=7.5,
                    tags=["authorization", "admin-access", "privilege-escalation"],
                ))

    def _test_method_tampering(self, ep: APIEndpoint):
        """Test if changing HTTP method bypasses authorization."""
        # If endpoint is GET-only, try destructive methods
        if ep.method == "GET":
            for method in ["DELETE", "PUT", "PATCH", "POST"]:
                resp = self.client.request(method, ep.full_url, json_body={})
                if resp and resp.status_code in (200, 201, 204):
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="HIGH",
                        title=f"Method tampering accepted — {method} {ep.path}",
                        description=f"Endpoint accepts {method} method when only {ep.method} was expected.",
                        endpoint=ep.full_url,
                        method=method,
                        evidence=f"{method} returned {resp.status_code} (expected 405).",
                        response_code=resp.status_code,
                        confidence="Medium",
                        remediation="Explicitly whitelist allowed HTTP methods per endpoint.",
                        references=[self.OWASP_REF],
                        cvss=6.5,
                        tags=["method-tampering", "authorization"],
                    ))
                    break

    def _test_method_override(self, ep: APIEndpoint):
        """Test HTTP method override headers."""
        for override in PayloadDB.METHOD_OVERRIDE_HEADERS[:3]:
            resp = self.client.get(ep.full_url, headers=override)
            if resp and resp.status_code in (200, 201, 204):
                header_name = list(override.keys())[0]
                overridden_method = override[header_name]
                # Compare with baseline GET
                baseline = self.client.get(ep.full_url)
                if baseline and resp.text != baseline.text:
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="MEDIUM",
                        title=f"Method override accepted — {ep.path}",
                        description=f"API honors {header_name}: {overridden_method} header.",
                        endpoint=ep.full_url,
                        method="GET",
                        evidence=f"Response differed when {header_name}: {overridden_method} was sent.",
                        response_code=resp.status_code,
                        confidence="Low",
                        remediation="Disable HTTP method override headers in production.",
                        references=[self.OWASP_REF],
                        cvss=5.3,
                        tags=["method-override", "authorization"],
                    ))
                    break
