"""
APIHound — API10:2023 Unsafe Consumption of APIs
Tests for redirect following, SSRF chains, and data validation on external inputs.
"""
import logging
from typing import List
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint

logger = logging.getLogger("apihound.checks.api10")


class UnsafeConsumptionCheck:
    CHECK_ID = "API10-CONSUMPTION"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xaa-unsafe-consumption-of-apis/"

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        logger.info(f"[{self.CHECK_ID}] Starting unsafe consumption checks")

        for ep in endpoints[:20]:
            self._test_redirect_following(ep)
            self._test_content_type_validation(ep)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    def _test_redirect_following(self, ep: APIEndpoint):
        """Check if API blindly follows redirects (potential SSRF chain)."""
        # Send request and check for redirect
        resp = self.client.request(ep.method, ep.full_url, follow_redirects=False)
        if not resp:
            return

        if resp.status_code in (301, 302, 307, 308):
            location = resp.headers.get("Location", "")
            # Now follow the redirect to see if the API consumes external content
            if location and ("http" in location or "//" in location):
                follow_resp = self.client.request(ep.method, ep.full_url, follow_redirects=True)
                if follow_resp and follow_resp.status_code == 200:
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="LOW",
                        title=f"API follows redirects — {ep.path}",
                        description=f"Endpoint redirects to {location} and follows it.",
                        endpoint=ep.full_url,
                        method=ep.method,
                        evidence=f"Redirect to: {location}",
                        response_code=resp.status_code,
                        confidence="Low",
                        remediation=(
                            "Validate redirect destinations. Do not blindly follow redirects "
                            "from third-party APIs. Validate response data from external sources."
                        ),
                        references=[self.OWASP_REF],
                        cvss=3.7,
                        tags=["redirect", "unsafe-consumption"],
                    ))

    def _test_content_type_validation(self, ep: APIEndpoint):
        """Send mismatched Content-Type to check if API validates input format."""
        if ep.method not in ("POST", "PUT", "PATCH"):
            return

        # Send XML body with JSON content-type
        xml_body = '<?xml version="1.0"?><root><test>1</test></root>'
        resp = self.client.request(
            ep.method, ep.full_url,
            raw_body=xml_body,
            headers={"Content-Type": "application/json"},
        )
        if resp and resp.status_code in (200, 201):
            self.findings.append(Finding(
                check_id=self.CHECK_ID,
                severity="LOW",
                title=f"Content-Type mismatch accepted — {ep.path}",
                description="API accepted XML body when Content-Type was application/json.",
                endpoint=ep.full_url,
                method=ep.method,
                evidence="XML payload accepted with JSON content-type header.",
                response_code=resp.status_code,
                confidence="Low",
                remediation="Validate that request body matches the Content-Type header.",
                references=[self.OWASP_REF],
                cvss=3.1,
                tags=["content-type", "validation"],
            ))
