"""
APIHound — API1:2023 Broken Object Level Authorization (BOLA)
Tests for Insecure Direct Object References (IDOR) by manipulating object IDs.
"""
import json
import logging
import re
from typing import List
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint
from payloads.payload_db import PayloadDB

logger = logging.getLogger("apihound.checks.api1")


class BOLACheck:
    """
    Test for Broken Object Level Authorization.
    Strategy:
      1. Identify endpoints with ID parameters (path, query, body).
      2. Send requests with sequential/guessed IDs as an authenticated user.
      3. Compare responses: if different object data is returned for other users'
         IDs, BOLA is confirmed.
    """

    CHECK_ID = "API1-BOLA"
    SEVERITY = "CRITICAL"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/"

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        """Execute BOLA checks against all endpoints with ID parameters."""
        logger.info(f"[{self.CHECK_ID}] Starting BOLA checks on {len(endpoints)} endpoints")

        candidates = [ep for ep in endpoints if ep.has_id_params()]
        logger.info(f"[{self.CHECK_ID}] {len(candidates)} endpoints have ID parameters")

        for ep in candidates:
            self._test_path_id_enum(ep)
            self._test_query_id_enum(ep)
            self._test_type_juggling(ep)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    def _test_path_id_enum(self, ep: APIEndpoint):
        """Test sequential ID enumeration in path parameters."""
        # Find path parameters that look like IDs
        id_params = [p for p in ep.parameters if p.location == "path" and
                     any(pat in p.name.lower() for pat in ["id", "uid", "uuid", "pk"])]

        if not id_params:
            # Also check raw path for {id} patterns
            id_matches = re.findall(r'\{(\w*id\w*)\}', ep.path, re.IGNORECASE)
            if not id_matches:
                return

        # Build test URLs with sequential IDs
        test_ids = PayloadDB.BOLA_ID_PAYLOADS["sequential_int"][:20]
        if self.config.user_id:
            test_ids = [self.config.user_id_other or "1"] + test_ids

        baseline_url = ep.full_url
        baseline_resp = self.client.get(baseline_url)
        if not baseline_resp:
            return

        for test_id in test_ids:
            # Replace ID placeholders in path
            test_url = re.sub(r'\{[^}]*id[^}]*\}', str(test_id), ep.full_url, flags=re.IGNORECASE)
            if test_url == ep.full_url:
                continue

            resp = self.client.get(test_url)
            if not resp:
                continue

            # Detection: 200 OK with different content suggests BOLA
            if resp.status_code == 200 and baseline_resp.status_code == 200:
                if resp.text != baseline_resp.text and len(resp.text) > 10:
                    self._report_finding(
                        ep, test_url, "GET", resp,
                        f"Different object returned for ID={test_id}. "
                        f"Baseline response length={len(baseline_resp.text)}, "
                        f"test response length={len(resp.text)}.",
                        confidence="Medium"
                    )
                    break  # One finding per endpoint is sufficient

            # Detection: 200 when accessing other user's resource
            elif resp.status_code == 200 and self.config.user_id_other:
                self._report_finding(
                    ep, test_url, "GET", resp,
                    f"Accessed object belonging to another user (ID={test_id}).",
                    confidence="High"
                )
                break

    def _test_query_id_enum(self, ep: APIEndpoint):
        """Test ID enumeration in query parameters."""
        id_params = [p for p in ep.parameters if p.location == "query" and
                     any(pat in p.name.lower() for pat in ["id", "uid", "user", "account", "pk"])]

        for param in id_params:
            test_ids = PayloadDB.BOLA_ID_PAYLOADS["sequential_int"][:10]

            for test_id in test_ids:
                resp = self.client.get(ep.full_url, params={param.name: test_id})
                if resp and resp.status_code == 200 and len(resp.text) > 20:
                    # Check for user-specific data in response
                    try:
                        data = resp.json()
                        if isinstance(data, dict) and any(
                            k in data for k in ["email", "username", "name", "phone", "address"]
                        ):
                            self._report_finding(
                                ep, ep.full_url, "GET", resp,
                                f"Query param '{param.name}={test_id}' returned "
                                f"user-specific data: {list(data.keys())[:10]}",
                                confidence="High"
                            )
                            break
                    except (json.JSONDecodeError, ValueError):
                        pass

    def _test_type_juggling(self, ep: APIEndpoint):
        """Test type juggling / unexpected ID types."""
        type_payloads = PayloadDB.BOLA_ID_PAYLOADS["type_juggling"]

        for payload in type_payloads[:5]:
            test_url = re.sub(r'\{[^}]*id[^}]*\}', str(payload), ep.full_url, flags=re.IGNORECASE)
            if test_url == ep.full_url:
                continue

            resp = self.client.get(test_url)
            if resp and resp.status_code == 200 and len(resp.text) > 20:
                self._report_finding(
                    ep, test_url, "GET", resp,
                    f"Type juggling with '{payload}' returned data "
                    f"(possible authorization bypass).",
                    confidence="Low"
                )
                break

    def _report_finding(self, ep, url, method, resp, evidence, confidence="Medium"):
        """Create and store a BOLA finding."""
        self.findings.append(Finding(
            check_id=self.CHECK_ID,
            severity=self.SEVERITY,
            title=f"BOLA — {ep.path}",
            description=(
                "The endpoint does not properly validate that the authenticated user "
                "is authorized to access the requested object. An attacker can enumerate "
                "object IDs to access other users' data."
            ),
            endpoint=url,
            method=method,
            evidence=evidence,
            request_raw=self.client.build_raw_request(method, url, self.config.get_headers()),
            response_raw=self.client.build_raw_response(resp) if resp else "",
            response_code=resp.status_code if resp else 0,
            confidence=confidence,
            remediation=(
                "Implement object-level authorization checks. Verify that the authenticated "
                "user owns or has access to the requested object before returning data. "
                "Use UUIDs instead of sequential IDs to reduce enumeration risk."
            ),
            references=[self.OWASP_REF],
            cvss=8.6,
            tags=["bola", "idor", "authorization"],
        ))
