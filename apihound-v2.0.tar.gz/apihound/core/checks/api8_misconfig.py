"""
APIHound — API8:2023 Security Misconfiguration
CORS misconfig, missing security headers, debug endpoints, verbose error messages.
"""
import json
import logging
from typing import List
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint
from payloads.payload_db import PayloadDB

logger = logging.getLogger("apihound.checks.api8")


class MisconfigCheck:
    CHECK_ID = "API8-MISCONFIG"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xa8-security-misconfiguration/"

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        logger.info(f"[{self.CHECK_ID}] Starting security misconfiguration checks")

        # Global checks (run once against base URL)
        self._test_cors_misconfiguration(endpoints)
        self._test_security_headers(endpoints)
        self._test_debug_endpoints()
        self._test_http_methods_allowed(endpoints)

        # Per-endpoint checks
        for ep in endpoints[:20]:
            self._test_verbose_errors(ep)
            self._test_stack_traces(ep)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    def _test_cors_misconfiguration(self, endpoints: List[APIEndpoint]):
        """Test for overly permissive CORS configuration."""
        test_origins = PayloadDB.MISCONFIG_CHECKS["cors_origins"]

        for ep in endpoints[:5]:
            for origin in test_origins:
                headers = {"Origin": origin}
                resp = self.client.request(ep.method, ep.full_url, headers=headers)
                if not resp:
                    continue

                acao = resp.headers.get("Access-Control-Allow-Origin", "")
                acac = resp.headers.get("Access-Control-Allow-Credentials", "")

                if acao == "*":
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="MEDIUM",
                        title=f"CORS wildcard origin — {ep.path}",
                        description="API returns Access-Control-Allow-Origin: * allowing any origin.",
                        endpoint=ep.full_url,
                        method=ep.method,
                        evidence=f"ACAO: {acao}, ACAC: {acac}",
                        response_code=resp.status_code,
                        confidence="High",
                        remediation="Restrict CORS to specific trusted origins. Never use wildcard with credentials.",
                        references=[self.OWASP_REF],
                        cvss=5.3,
                        tags=["cors", "misconfiguration"],
                    ))
                    return

                if origin in acao and "true" in acac.lower():
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="HIGH",
                        title=f"CORS reflects arbitrary origin with credentials — {ep.path}",
                        description=f"API reflects attacker origin '{origin}' with Allow-Credentials: true.",
                        endpoint=ep.full_url,
                        method=ep.method,
                        evidence=f"Origin: {origin} → ACAO: {acao}, ACAC: {acac}",
                        response_code=resp.status_code,
                        confidence="High",
                        remediation="Never reflect untrusted origins. Use a strict allowlist.",
                        references=[self.OWASP_REF],
                        cvss=7.5,
                        tags=["cors", "credential-theft"],
                    ))
                    return

                if acao == "null" and "true" in acac.lower():
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="HIGH",
                        title=f"CORS allows null origin with credentials — {ep.path}",
                        description="API allows 'null' origin with credentials, exploitable via sandboxed iframes.",
                        endpoint=ep.full_url,
                        method=ep.method,
                        evidence=f"Origin: null → ACAO: null, ACAC: true",
                        response_code=resp.status_code,
                        confidence="High",
                        remediation="Never allow 'null' origin. Block all non-allowlisted origins.",
                        references=[self.OWASP_REF],
                        cvss=7.5,
                        tags=["cors", "null-origin"],
                    ))
                    return

    def _test_security_headers(self, endpoints: List[APIEndpoint]):
        """Check for missing security headers."""
        if not endpoints:
            return

        ep = endpoints[0]
        resp = self.client.request(ep.method, ep.full_url)
        if not resp:
            return

        required = PayloadDB.MISCONFIG_CHECKS["security_headers_required"]
        missing = [h for h in required if h.lower() not in {k.lower() for k in resp.headers}]

        if missing:
            self.findings.append(Finding(
                check_id=self.CHECK_ID,
                severity="LOW",
                title="Missing security headers",
                description=f"The API is missing {len(missing)} recommended security headers.",
                endpoint=ep.full_url,
                method=ep.method,
                evidence=f"Missing: {', '.join(missing)}",
                response_code=resp.status_code,
                confidence="High",
                remediation="Add security headers: " + ", ".join(missing),
                references=[self.OWASP_REF],
                cvss=3.7,
                tags=["headers", "misconfiguration"],
            ))

        # Check for server version disclosure
        server = resp.headers.get("Server", "")
        x_powered = resp.headers.get("X-Powered-By", "")
        if server and any(c.isdigit() for c in server):
            self.findings.append(Finding(
                check_id=self.CHECK_ID,
                severity="LOW",
                title="Server version disclosure",
                description=f"Server header discloses version: {server}",
                endpoint=ep.full_url,
                method=ep.method,
                evidence=f"Server: {server}",
                response_code=resp.status_code,
                confidence="High",
                remediation="Remove or genericize the Server header.",
                references=[self.OWASP_REF],
                cvss=2.7,
                tags=["information-disclosure"],
            ))
        if x_powered:
            self.findings.append(Finding(
                check_id=self.CHECK_ID,
                severity="LOW",
                title="Technology disclosure via X-Powered-By",
                description=f"X-Powered-By header reveals: {x_powered}",
                endpoint=ep.full_url,
                method=ep.method,
                evidence=f"X-Powered-By: {x_powered}",
                response_code=resp.status_code,
                confidence="High",
                remediation="Remove the X-Powered-By header.",
                references=[self.OWASP_REF],
                cvss=2.7,
                tags=["information-disclosure"],
            ))

    def _test_debug_endpoints(self):
        """Probe for debug/development endpoints."""
        base = self.config.target_url.rstrip("/")

        for path in PayloadDB.MISCONFIG_CHECKS["debug_endpoints"]:
            url = f"{base}{path}"
            resp = self.client.get(url)
            if resp and resp.status_code == 200 and len(resp.text) > 50:
                self.findings.append(Finding(
                    check_id=self.CHECK_ID,
                    severity="HIGH",
                    title=f"Debug/sensitive endpoint exposed — {path}",
                    description=f"The endpoint {path} is accessible and returns content.",
                    endpoint=url,
                    method="GET",
                    evidence=f"200 OK, {len(resp.text)} bytes returned.",
                    response_code=200,
                    confidence="High",
                    remediation="Remove or restrict access to debug endpoints in production.",
                    references=[self.OWASP_REF],
                    cvss=7.5,
                    tags=["debug", "exposed-endpoint"],
                ))

    def _test_http_methods_allowed(self, endpoints: List[APIEndpoint]):
        """Check OPTIONS response for overly permissive methods."""
        for ep in endpoints[:5]:
            resp = self.client.options(ep.full_url)
            if not resp:
                continue
            allow = resp.headers.get("Allow", resp.headers.get("Access-Control-Allow-Methods", ""))
            if allow:
                dangerous = {"DELETE", "PUT", "PATCH", "TRACE", "CONNECT"}
                allowed_set = {m.strip().upper() for m in allow.split(",")}
                found_dangerous = allowed_set & dangerous
                if "TRACE" in found_dangerous:
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="MEDIUM",
                        title=f"TRACE method enabled — {ep.path}",
                        description="TRACE method is enabled, potentially allowing XST attacks.",
                        endpoint=ep.full_url,
                        method="OPTIONS",
                        evidence=f"Allow: {allow}",
                        response_code=resp.status_code,
                        confidence="High",
                        remediation="Disable TRACE and CONNECT methods.",
                        references=[self.OWASP_REF],
                        cvss=4.3,
                        tags=["trace", "xst"],
                    ))
                    break

    def _test_verbose_errors(self, ep: APIEndpoint):
        """Trigger error responses and check for verbose information."""
        for trigger in PayloadDB.MISCONFIG_CHECKS["verbose_error_triggers"][:3]:
            resp = self.client.get(ep.full_url, params=trigger)
            if not resp or resp.status_code not in (400, 500, 422):
                continue

            body = resp.text.lower()
            verbose_sigs = [
                "traceback", "stack trace", "at line", "exception in",
                "syntax error", "sql", "mysql", "postgresql", "oracle",
                "mongodb", "django", "flask", "express", "spring",
                "internal server error", "debug", "file \"",
                "java.lang.", "system.nullreferenceexception",
                "phpwarning", "undefined variable",
            ]
            found = [sig for sig in verbose_sigs if sig in body]
            if found:
                self.findings.append(Finding(
                    check_id=self.CHECK_ID,
                    severity="MEDIUM",
                    title=f"Verbose error message — {ep.path}",
                    description="Error response contains stack traces or internal details.",
                    endpoint=ep.full_url,
                    method="GET",
                    evidence=f"Error signatures found: {found[:5]}",
                    response_code=resp.status_code,
                    confidence="High",
                    remediation="Return generic error messages in production. Log details server-side only.",
                    references=[self.OWASP_REF],
                    cvss=5.3,
                    tags=["verbose-errors", "information-disclosure"],
                ))
                return

    def _test_stack_traces(self, ep: APIEndpoint):
        """Send malformed requests to trigger stack traces."""
        # Send invalid JSON
        resp = self.client.request(
            "POST", ep.full_url,
            raw_body="{{{{invalid json",
            headers={"Content-Type": "application/json"},
        )
        if resp and resp.status_code >= 400:
            body = resp.text.lower()
            if any(s in body for s in ["traceback", "exception", "stack", "at line"]):
                self.findings.append(Finding(
                    check_id=self.CHECK_ID,
                    severity="MEDIUM",
                    title=f"Stack trace in malformed request error — {ep.path}",
                    description="Sending invalid JSON triggered a detailed stack trace.",
                    endpoint=ep.full_url,
                    method="POST",
                    evidence=f"Invalid JSON → {resp.status_code} with debug info.",
                    response_code=resp.status_code,
                    confidence="High",
                    remediation="Sanitize all error responses. Never expose internals to clients.",
                    references=[self.OWASP_REF],
                    cvss=5.3,
                    tags=["stack-trace", "information-disclosure"],
                ))
