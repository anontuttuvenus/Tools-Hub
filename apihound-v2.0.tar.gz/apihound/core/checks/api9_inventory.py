"""
APIHound — API9:2023 Improper Inventory Management
Old API versions, undocumented endpoints, shadow APIs.
"""
import logging
import re
from typing import List
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint
from payloads.payload_db import PayloadDB

logger = logging.getLogger("apihound.checks.api9")


class InventoryCheck:
    CHECK_ID = "API9-INVENTORY"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xa9-improper-inventory-management/"

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        logger.info(f"[{self.CHECK_ID}] Starting inventory management checks")

        self._test_old_api_versions(endpoints)
        self._test_undocumented_endpoints(endpoints)
        self._test_deprecated_headers(endpoints)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    def _test_old_api_versions(self, endpoints: List[APIEndpoint]):
        """Enumerate old API versions that may still be active."""
        base = self.config.target_url.rstrip("/")
        # Determine current version from known endpoints
        current_versions = set()
        for ep in endpoints:
            m = re.search(r'/(v\d+|api/v\d+)', ep.path)
            if m:
                current_versions.add(m.group())

        for path in PayloadDB.API_VERSION_PATHS:
            if path in current_versions:
                continue  # Skip current version

            url = f"{base}{path}"
            resp = self.client.get(url)
            if resp and resp.status_code in (200, 301, 302) and len(resp.text) > 20:
                self.findings.append(Finding(
                    check_id=self.CHECK_ID,
                    severity="MEDIUM",
                    title=f"Old/alternate API version accessible — {path}",
                    description=(
                        "An older or alternate API version is still accessible. "
                        "Old versions may lack security patches."
                    ),
                    endpoint=url,
                    method="GET",
                    evidence=f"{path} → {resp.status_code} ({len(resp.text)} bytes).",
                    response_code=resp.status_code,
                    confidence="Medium",
                    remediation="Decommission old API versions. Redirect to current version.",
                    references=[self.OWASP_REF],
                    cvss=5.3,
                    tags=["inventory", "deprecated-api"],
                ))

    def _test_undocumented_endpoints(self, endpoints: List[APIEndpoint]):
        """If spec was loaded, check for endpoints not in spec."""
        if not endpoints:
            return
        # This is meaningful when crawled endpoints are compared against spec
        # For now, flag endpoints found by crawler that have interesting patterns
        undocumented_patterns = [
            "internal", "debug", "test", "dev", "staging", "admin",
            "backdoor", "hidden", "secret", "private", "beta",
        ]
        for ep in endpoints:
            path_lower = ep.path.lower()
            matched = [p for p in undocumented_patterns if p in path_lower]
            if matched:
                self.findings.append(Finding(
                    check_id=self.CHECK_ID,
                    severity="LOW",
                    title=f"Potentially undocumented endpoint — {ep.path}",
                    description=f"Endpoint contains patterns suggesting it's internal/undocumented: {matched}",
                    endpoint=ep.full_url,
                    method=ep.method,
                    evidence=f"Path contains: {matched}",
                    confidence="Low",
                    remediation="Review and remove or protect internal/debug endpoints.",
                    references=[self.OWASP_REF],
                    cvss=3.7,
                    tags=["inventory", "shadow-api"],
                ))

    def _test_deprecated_headers(self, endpoints: List[APIEndpoint]):
        """Check for deprecation-related headers in responses."""
        for ep in endpoints[:10]:
            resp = self.client.request(ep.method, ep.full_url)
            if not resp:
                continue
            deprecation = resp.headers.get("Deprecation") or resp.headers.get("Sunset")
            if deprecation:
                self.findings.append(Finding(
                    check_id=self.CHECK_ID,
                    severity="INFO",
                    title=f"Deprecated API endpoint — {ep.path}",
                    description=f"Endpoint is marked as deprecated: {deprecation}",
                    endpoint=ep.full_url,
                    method=ep.method,
                    evidence=f"Deprecation/Sunset header: {deprecation}",
                    confidence="High",
                    remediation="Migrate consumers to the current API version and decommission deprecated endpoints.",
                    references=[self.OWASP_REF],
                    cvss=2.0,
                    tags=["inventory", "deprecated"],
                ))
