"""
APIHound — Scanner Orchestrator
Coordinates all check modules, manages endpoints, and collects findings.
"""
import logging
import time
from typing import List
from core.config import ScanConfig, Finding, SEVERITY_ORDER
from core.http_client import HTTPClient
from core.openapi_parser import OpenAPIParser, APIEndpoint
from core.crawler import APICrawler
from core.checks import ALL_CHECKS
from waf_bypass.waf_engine import WAFBypassEngine

logger = logging.getLogger("apihound.scanner")


class Scanner:
    """Main scan orchestrator."""

    def __init__(self, config: ScanConfig):
        self.config = config
        self.waf_engine = WAFBypassEngine() if config.waf_bypass else None
        self.client = HTTPClient(config, self.waf_engine)
        self.endpoints: List[APIEndpoint] = []
        self.findings: List[Finding] = []
        self.scan_start = 0.0
        self.scan_duration = 0.0

    def run(self) -> List[Finding]:
        """Execute the full scan pipeline."""
        self.scan_start = time.time()
        logger.info("=" * 60)
        logger.info("APIHound v2.0 — OWASP API Security Scanner")
        logger.info("=" * 60)

        # Phase 1: Discover endpoints
        self._discover_endpoints()

        if not self.endpoints:
            logger.error("No endpoints discovered. Provide --spec or --target with --crawl.")
            return []

        logger.info(f"Total endpoints to test: {len(self.endpoints)}")

        # Phase 2: Run selected checks
        selected = self._resolve_checks()
        logger.info(f"Running checks: {list(selected.keys())}")

        for check_id, check_cls in selected.items():
            try:
                logger.info(f"--- Running {check_id} ---")
                check = check_cls(self.config, self.client)
                results = check.run(self.endpoints)
                self.findings.extend(results)
                logger.info(f"--- {check_id}: {len(results)} findings ---")
            except Exception as e:
                logger.error(f"Check {check_id} failed: {e}", exc_info=True)

        # Phase 3: Sort and deduplicate
        self._sort_findings()

        self.scan_duration = time.time() - self.scan_start
        logger.info("=" * 60)
        logger.info(f"Scan complete in {self.scan_duration:.1f}s")
        logger.info(f"Total findings: {len(self.findings)}")
        self._print_summary()
        logger.info("=" * 60)

        return self.findings

    def _discover_endpoints(self):
        """Load endpoints from spec and/or crawling."""
        # From OpenAPI spec
        if self.config.spec_path:
            parser = OpenAPIParser(self.config.target_url)
            spec_data = self._load_spec()
            if spec_data:
                self.endpoints.extend(parser.parse(spec_data))
                if not self.config.target_url and parser.base_url:
                    self.config.target_url = parser.base_url

        # From crawling
        if self.config.crawl and self.config.target_url:
            crawler = APICrawler(self.config, self.client)
            crawled = crawler.crawl(self.config.target_url)
            # Merge with existing endpoints (avoid duplicates)
            existing = {f"{e.method}:{e.path}" for e in self.endpoints}
            for ep in crawled:
                key = f"{ep.method}:{ep.path}"
                if key not in existing:
                    self.endpoints.append(ep)
                    existing.add(key)

        # Ensure all endpoints have full URLs
        base = self.config.target_url.rstrip("/") if self.config.target_url else ""
        for ep in self.endpoints:
            if not ep.full_url and base:
                ep.full_url = f"{base}{ep.path}"

    def _load_spec(self) -> str:
        """Load spec from file path or URL."""
        path = self.config.spec_path
        if path.startswith("http://") or path.startswith("https://"):
            resp = self.client.get(path)
            return resp.text if resp else ""
        else:
            try:
                with open(path) as f:
                    return f.read()
            except FileNotFoundError:
                logger.error(f"Spec file not found: {path}")
                return ""

    def _resolve_checks(self) -> dict:
        """Determine which checks to run based on config."""
        if "all" in self.config.checks:
            return dict(ALL_CHECKS)

        selected = {}
        for check_id in self.config.checks:
            check_id = check_id.strip().lower()
            if check_id in ALL_CHECKS:
                selected[check_id] = ALL_CHECKS[check_id]
            else:
                logger.warning(f"Unknown check: {check_id}")
        return selected or dict(ALL_CHECKS)

    def _sort_findings(self):
        """Sort findings by severity (CRITICAL first)."""
        self.findings.sort(key=lambda f: SEVERITY_ORDER.get(f.severity, 99))

    def _print_summary(self):
        """Print severity summary to console."""
        counts = {}
        for f in self.findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
            if sev in counts:
                logger.info(f"  {sev}: {counts[sev]}")

    def get_scan_metadata(self) -> dict:
        """Return scan metadata for reporting."""
        return {
            "target": self.config.target_url,
            "spec": self.config.spec_path,
            "endpoints_tested": len(self.endpoints),
            "total_findings": len(self.findings),
            "scan_duration_seconds": round(self.scan_duration, 1),
            "checks_run": self.config.checks,
            "waf_bypass": self.config.waf_bypass,
            "requests_sent": self.client.stats.get("requests", 0),
            "errors": self.client.stats.get("errors", 0),
            "waf_blocks": self.client.stats.get("waf_blocks", 0),
        }

    def close(self):
        """Clean up resources."""
        self.client.close()
