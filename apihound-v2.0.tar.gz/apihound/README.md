# APIHound v2.0 — OWASP API Security Top 10 Scanner

**Automated API penetration testing tool aligned with OWASP API Security Top 10 (2023)**

> ⚠️ **Authorized testing only.** Use exclusively against targets you have written permission to test.

## Architecture

```
apihound/
├── apihound.py              # CLI entry point
├── core/
│   ├── __init__.py
│   ├── config.py             # Global config, rate limiting, logging
│   ├── http_client.py        # Async HTTP engine (httpx) with retry/proxy/WAF evasion
│   ├── openapi_parser.py     # OpenAPI/Swagger spec importer + endpoint discovery
│   ├── crawler.py            # API endpoint crawler + fuzzer
│   ├── scanner.py            # Orchestrator — runs all check modules
│   ├── reporter.py           # HTML + JSON report generator with PoC replay
│   └── checks/
│       ├── __init__.py
│       ├── api1_bola.py              # Broken Object Level Authorization
│       ├── api2_broken_auth.py       # Broken Authentication
│       ├── api3_property_auth.py     # Broken Object Property Level Authorization
│       ├── api4_resource_consumption.py  # Unrestricted Resource Consumption
│       ├── api5_function_auth.py     # Broken Function Level Authorization
│       ├── api6_business_flow.py     # Unrestricted Access to Sensitive Business Flows
│       ├── api7_ssrf.py              # Server Side Request Forgery
│       ├── api8_misconfig.py         # Security Misconfiguration
│       ├── api9_inventory.py         # Improper Inventory Management
│       ├── api10_unsafe_consumption.py   # Unsafe Consumption of APIs
│       ├── injection.py              # SQLi, NoSQLi, CMDi, XSS, XXE, SSTI
│       └── jwt_attacks.py            # JWT none-alg, key confusion, claim tampering
├── payloads/
│   ├── __init__.py
│   └── payload_db.py         # 1200+ payloads organized by vuln class
├── wordlists/
│   ├── __init__.py
│   ├── wordlist_manager.py   # SecLists integration + built-in lists
│   ├── api_endpoints.txt     # Common API paths
│   ├── api_params.txt        # Common parameter names
│   └── api_versions.txt      # Version path prefixes
├── waf_bypass/
│   ├── __init__.py
│   └── waf_engine.py         # Encoding, obfuscation, verb tampering, header tricks
├── burp_extension/
│   └── apihound_burp.py      # Montoya API (Burp Suite) extension
├── reports/                   # Output directory for scan results
├── templates/
│   └── report.html            # Jinja2 HTML report template
├── requirements.txt
└── setup.py
```

## OWASP API Security Top 10 (2023) Coverage

| ID | Vulnerability | Checks Implemented |
|----|---------------|-------------------|
| API1 | Broken Object Level Authorization | IDOR via ID enumeration, UUID prediction, path traversal on object refs |
| API2 | Broken Authentication | Weak JWT, credential stuffing, token replay, missing rate limits |
| API3 | Broken Object Property Level Auth | Mass assignment, excessive data exposure, field-level access |
| API4 | Unrestricted Resource Consumption | Missing rate limits, pagination abuse, large payload DoS |
| API5 | Broken Function Level Authorization | Admin endpoint access, HTTP method tampering, privilege escalation |
| API6 | Unrestricted Access to Business Flows | Automation abuse detection, missing CAPTCHA/anti-bot |
| API7 | Server Side Request Forgery | URL parameter injection, redirect abuse, cloud metadata |
| API8 | Security Misconfiguration | CORS, verbose errors, debug endpoints, missing security headers |
| API9 | Improper Inventory Management | Old API versions, undocumented endpoints, shadow APIs |
| API10 | Unsafe Consumption of APIs | Redirect following, SSRF chains, data validation bypass |
| +   | Injection (SQLi/NoSQLi/CMDi/XSS/XXE/SSTI) | 200+ injection payloads per class |
| +   | JWT Attacks | none-alg, HS256/RS256 confusion, claim tamper, expired tokens |

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
# Scan from OpenAPI spec
python apihound.py --spec https://target.com/api/docs/openapi.json --auth "Bearer TOKEN"

# Scan with crawling + fuzzing
python apihound.py --target https://target.com/api --crawl --fuzz --auth "Bearer TOKEN"

# Scan specific OWASP categories
python apihound.py --spec spec.yaml --checks api1,api2,api8,injection

# WAF evasion mode
python apihound.py --target https://target.com/api --waf-bypass --proxy http://127.0.0.1:8080

# Validate against vAPI (local lab)
python apihound.py --target http://localhost:3000 --crawl --fuzz --lab-mode

# Full scan with HTML + JSON report
python apihound.py --spec spec.yaml --auth "Bearer TOKEN" --output reports/scan_001 --format html,json

# Burp proxy integration
python apihound.py --spec spec.yaml --proxy http://127.0.0.1:8080 --auth "Bearer TOKEN"
```

## CLI Options

| Flag | Description |
|------|-------------|
| `--spec` | Path or URL to OpenAPI/Swagger spec (JSON or YAML) |
| `--target` | Base URL for crawl/fuzz mode |
| `--auth` | Authorization header value |
| `--auth-cookie` | Cookie-based auth string |
| `--checks` | Comma-separated check IDs (default: all) |
| `--crawl` | Enable endpoint crawling |
| `--fuzz` | Enable parameter/path fuzzing |
| `--waf-bypass` | Enable WAF evasion mode |
| `--proxy` | HTTP/SOCKS proxy (e.g., Burp Suite) |
| `--rate-limit` | Requests per second (default: 10) |
| `--delay` | Fixed delay between requests in ms (default: 0) |
| `--timeout` | Request timeout in seconds (default: 15) |
| `--threads` | Concurrent workers (default: 5) |
| `--output` | Output directory for reports |
| `--format` | Report format: html, json, or both |
| `--lab-mode` | Relaxed thresholds for testing against vulnerable labs |
| `--verbose` | Verbose output |
| `--user-id` | Known user ID for BOLA testing |
| `--user-id-other` | Other user's ID for BOLA comparison |

## Burp Suite Extension

Copy `burp_extension/apihound_burp.py` into Burp Suite via Extender → Add → Python.
Requires Jython 2.7+ standalone JAR. Uses Montoya API for Burp Suite 2023+.

## Testing Against Vulnerable Labs

```bash
# vAPI (https://github.com/roottusk/vapi)
docker pull roottusk/vapi && docker run -p 3000:3000 roottusk/vapi
python apihound.py --target http://localhost:3000 --crawl --fuzz --lab-mode

# DVGA (Damn Vulnerable GraphQL Application)
docker pull dolevf/dvga && docker run -p 5013:5013 dolevf/dvga
python apihound.py --target http://localhost:5013 --crawl --lab-mode
```

## References

- [OWASP API Security Top 10 2023](https://owasp.org/API-Security/editions/2023/en/0x00-header/)
- [OWASP Web Security Testing Guide — API Testing](https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/12-API_Testing/)
- [PortSwigger — API Testing](https://portswigger.net/web-security/api-testing)
- [SecLists](https://github.com/danielmiessler/seclists)
- [shieldfy/API-Security-Checklist](https://github.com/shieldfy/API-Security-Checklist)
- [arainho/awesome-api-security](https://github.com/arainho/awesome-api-security)

## License

MIT — For authorized security testing and research only.
